const express = require('express')
const app = express()
const port = 3000

app.use('/', express.static('./'))

let server = app.listen(port, function () {
    var host = server.address().address
    // var port = server.address().port

    console.log("Example app listening at http://%s:%s", host, port)
})